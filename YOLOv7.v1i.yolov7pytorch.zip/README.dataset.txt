# YOLOv7 > 2022-10-11 6:51pm
https://universe.roboflow.com/fordataset/yolov7-hiqkc

Provided by a Roboflow user
License: Public Domain

